package com.example.tvassignment;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import com.bumptech.glide.Glide;

import java.util.ArrayList;
import java.util.List;

public class CharacterAdapter extends RecyclerView.Adapter<CharacterAdapter.CharacterViewHolder> {
    private List<Character> characterList;
    private List<Character> characterListFull;
    private Context context;
    private OnCharacterClickListener listener;

    public interface OnCharacterClickListener {
        void onCharacterClick(Character character);
    }

    public CharacterAdapter(Context context, List<Character> characterList, OnCharacterClickListener listener) {
        this.context = context;
        this.characterList = characterList;
        this.characterListFull = new ArrayList<>(characterList);
        this.listener = listener;
    }

    @NonNull
    @Override
    public CharacterViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(context).inflate(R.layout.character_item, parent, false);
        return new CharacterViewHolder(view, listener, characterList);
    }

    @Override
    public void onBindViewHolder(@NonNull CharacterViewHolder holder, int position) {
        Character character = characterList.get(position);
        holder.nameTextView.setText(character.getName());
        holder.descriptionTextView.setText(character.getDescription());
        
        Glide.with(context)
                .load(character.getImageResourceId())
                .centerCrop()
                .into(holder.imageView);
    }

    @Override
    public int getItemCount() {
        return characterList.size();
    }

    public void filter(String text) {
        characterList.clear();
        if (text.isEmpty()) {
            characterList.addAll(characterListFull);
        } else {
            text = text.toLowerCase();
            for (Character character : characterListFull) {
                if (character.getName().toLowerCase().contains(text) ||
                    character.getDescription().toLowerCase().contains(text)) {
                    characterList.add(character);
                }
            }
        }
        notifyDataSetChanged();
    }

    static class CharacterViewHolder extends RecyclerView.ViewHolder {
        ImageView imageView;
        TextView nameTextView;
        TextView descriptionTextView;
        private final OnCharacterClickListener listener;
        private final List<Character> characterList;

        CharacterViewHolder(@NonNull View itemView, OnCharacterClickListener listener, List<Character> characterList) {
            super(itemView);
            this.listener = listener;
            this.characterList = characterList;
            imageView = itemView.findViewById(R.id.character_image);
            nameTextView = itemView.findViewById(R.id.character_name);
            descriptionTextView = itemView.findViewById(R.id.character_description);

            itemView.setOnClickListener(v -> {
                int position = getAdapterPosition();
                if (position != RecyclerView.NO_POSITION && listener != null) {
                    listener.onCharacterClick(characterList.get(position));
                }
            });
        }
    }
} 