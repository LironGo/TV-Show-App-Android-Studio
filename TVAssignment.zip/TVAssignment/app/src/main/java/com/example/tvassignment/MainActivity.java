package com.example.tvassignment;

import android.os.Bundle;
import android.text.Editable;
import android.text.TextWatcher;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.TextView;
import android.view.View;
import android.widget.Toast;


import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.bumptech.glide.Glide;

import java.util.ArrayList;
import java.util.List;

public class MainActivity extends AppCompatActivity implements CharacterAdapter.OnCharacterClickListener {

    private CharacterAdapter adapter;
    private List<Character> characterList;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        initializeCharacterList();
        setupRecyclerView();
        setupSearchFunctionality();
    }

    private void initializeCharacterList() {
        characterList = new ArrayList<>();
        // Add Dragon Ball Z characters
        characterList.add(new Character("Goku", "The main protagonist, a Saiyan warrior known for his pure heart and love of fighting", R.drawable.goku));
        characterList.add(new Character("Vegeta", "The proud prince of all Saiyans, initially a villain who becomes one of Earth's greatest defenders", R.drawable.vegeta));
        characterList.add(new Character("Gohan", "Goku's first son, a half-Saiyan with incredible hidden potential", R.drawable.gohan));
        characterList.add(new Character("Piccolo", "A Namekian warrior who becomes Gohan's mentor and one of Earth's strongest defenders", R.drawable.piccolo));
        characterList.add(new Character("Trunks", "Vegeta's son from the future, who came to warn the Z fighters about the androids", R.drawable.trunks));
        characterList.add(new Character("Krillin", "Goku's best friend and the strongest human warrior", R.drawable.krillin));
        characterList.add(new Character("Bulma", "A brilliant scientist and inventor, Vegeta's wife and Trunks' mother", R.drawable.bulma));
        characterList.add(new Character("Cell", "A bio-android created by Dr. Gero, seeking to become perfect by absorbing androids 17 and 18", R.drawable.cell));
        characterList.add(new Character("Frieza", "The tyrannical emperor of the universe and one of Goku's greatest enemies", R.drawable.frieza));
        characterList.add(new Character("Majin Buu", "A magical being created by the wizard Bibidi, with tremendous power and multiple forms", R.drawable.majin_buu));
    }

    private void setupRecyclerView() {
        RecyclerView recyclerView = findViewById(R.id.recycler_view);
        recyclerView.setLayoutManager(new LinearLayoutManager(this));
        adapter = new CharacterAdapter(this, characterList, this);
        recyclerView.setAdapter(adapter);
    }

    private void setupSearchFunctionality() {
        EditText searchEditText = findViewById(R.id.search_edit_text);
        searchEditText.addTextChangedListener(new TextWatcher() {
            @Override
            public void beforeTextChanged(CharSequence s, int start, int count, int after) {}

            @Override
            public void onTextChanged(CharSequence s, int start, int before, int count) {
                adapter.filter(s.toString());
            }

            @Override
            public void afterTextChanged(Editable s) {}
        });
    }

    @Override
    public void onCharacterClick(Character character) {
        // Create and show the dialog
        AlertDialog.Builder builder = new AlertDialog.Builder(this);
        View dialogView = getLayoutInflater().inflate(R.layout.character_detail_dialog, null);

        // Initialize dialog views
        ImageView characterImage = dialogView.findViewById(R.id.dialog_character_image);
        TextView characterName = dialogView.findViewById(R.id.dialog_character_name);
        TextView characterDescription = dialogView.findViewById(R.id.dialog_character_description);

        // Set the data
        Glide.with(this)
                .load(character.getImageResourceId())
                .into(characterImage);
        characterName.setText(character.getName());
        characterDescription.setText(character.getDescription());

        // Create and show the dialog
        builder.setView(dialogView)
                .setPositiveButton("Close", (dialog, which) -> dialog.dismiss());

        AlertDialog dialog = builder.create();
        dialog.show();
    }
}